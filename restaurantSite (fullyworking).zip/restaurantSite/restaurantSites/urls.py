from django.urls import path
from django.shortcuts import render
from .views import indexPageView
from .views import reviewersPageView
from .views import addReviewPageView
from .views import updateReviewerPageView
from .views import deletePageView
from .views import viewReviewerPageView
from .views import viewreviewsPageView
from .views import storeReviewerPageView
from .views import addReviewerPageView
from .views import searchDisplayPageView
from .views import restaurantsPageView
from .views import deleteReviewerPageView


urlpatterns = [
    path("", indexPageView, name="index"),
    path("reviewers/", reviewersPageView, name="reviewers"),
    path("addReview/", addReviewPageView, name = "addReview"),
    path("read/", restaurantsPageView, name = "read"),
    path("updatereviewer/<str:reviewer>/", updateReviewerPageView, name = "updateReviewer"),
    path("delete/", deletePageView, name = "delete"),
    path("reviews/<str:restaurant>/", viewreviewsPageView, name = "reviews"),
    path("viewreviewer/<str:reviewer>/", viewReviewerPageView, name = "viewReviewer"),
    path("storeReviewerPageView/<str:reviewer>/", storeReviewerPageView, name = "storeReviewer"),
    path("addreviewer/", addReviewerPageView, name = "addReviewer"),
    path("search/", searchDisplayPageView, name="search"),
    path("deleteReviewer/<str:reviewer>/", deleteReviewerPageView, name= 'deleteReviewer'),
]