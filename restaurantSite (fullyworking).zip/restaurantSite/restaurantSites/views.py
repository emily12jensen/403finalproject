from django.shortcuts import render
from django.http import HttpResponse
from .models import Reviewer, Restaurant, Review

# Index
def indexPageView(request) :  
    return render(request, 'restaurantSites/index.html') 

# CRUD
def reviewersPageView(request) :
    reviewerlist = Reviewer.objects.all().order_by('lastName','firstName')

    context = {
        'reviewerlist': reviewerlist
    }
    return render(request, 'restaurantSites/reviewers.html', context) 

def restaurantsPageView(request):
    record = Restaurant.objects.all().order_by('restname')
    context ={
        'record': record
    }
    return render(request, 'restaurantSites/restaurants.html', context)
    

# Create
def addReviewPageView(request):

    if request.method == 'POST':
        
        revName = Reviewer.objects.get()
        resName = Restaurant.objects.get()
        review = Review()

        review.serviceQuality = request.POST.get('serviceQuality')
        review.timeliness = request.POST.get('timeliness')
        review.authenticity = request.POST.get('authenticity')
        review.vibe = request.POST.get('vibe')
        review.rating = request.POST.get('rating')
        review.comment = request.POST.get('comment')

        review.save()


        return restaurantsPageView(request)
    else:
        reviewers = Reviewer.objects.all().order_by('lastName', 'firstName')
        restaurants = Restaurant.objects.all().order_by('restname')
        context = {
            'reviewers':reviewers,
            'restaurant':restaurants
        }
        return render(request, 'restaurantSites/addReview.html', context)
    
# Update
def updateReviewerPageView(request, reviewer):
    reviewer = Reviewer.objects.get(reviewer=reviewer)

    context={
        "reviewer": reviewer
    }

    return render(request, 'restaurantSites/updateReviewer.html', context)
    
#Delete
def deletePageView(request):
    return render(request, 'restaurantSites/reviewers.html')

def viewReviewerPageView(request, reviewer):
    reviewer = Reviewer.objects.get(reviewer=reviewer)

    context={
        "reviewer": reviewer
    }

    return render(request, 'restaurantSites/viewReviewer.html', context)


# view reviews of each website
def viewreviewsPageView(request, restaurant):
    data = Review.objects.filter(restaurant=restaurant)

    context={
        "review": data
    }

    return render(request, 'restaurantSites/reviews.html', context)

def storeReviewerPageView(request, reviewer):
    reviewerlist = Reviewer.objects.all().order_by('lastName','firstName')

    reviewer = Reviewer.objects.get(reviewer=reviewer)

    sNewFirstName = request.POST['firstName']
    sNewLastName = request.POST['lastName']
    iNewAge = request.POST['age']
    reviewer.firstName = sNewFirstName
    reviewer.lastName = sNewLastName
    reviewer.age = iNewAge
    reviewer.save()

    context = {
        'reviewerlist': reviewerlist
    }
    return render(request, 'restaurantSites/reviewers.html', context)

def addReviewerPageView(request):
    if request.method == 'POST':
        reviewerlist = Reviewer.objects.all().order_by('lastName','firstName')
        reviewer = Reviewer()

        reviewer.firstName = request.POST['firstName']
        reviewer.lastName = request.POST['lastName']
        reviewer.age = request.POST['age']

        reviewer.save()
        context = {
            'reviewerlist': reviewerlist
        }
        return render(request, 'restaurantSites/reviewers.html', context)
    return render (request, 'restaurantSites/addReviewer.html')
    
 
def searchDisplayPageView(request):
    rName = request.GET.get('restaurantname')
    data = Restaurant.objects.filter(restname=rName)

    # if data.count() > 0:
    context = {
        "data": data
    }

    return render(request, 'restaurantSites/searchDisplay.html', context)

def deleteReviewerPageView(request, reviewer):
    reviewerlist = Reviewer.objects.all().order_by('lastName','firstName')
    reviewer = Reviewer.objects.filter(reviewer=reviewer).delete()

    return reviewersPageView(request)