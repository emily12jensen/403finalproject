from django.db import models
# Create your models here.

class Reviewer(models.Model) :
    reviewer = models.AutoField(primary_key=True)
    firstName = models.CharField(max_length=30)
    lastName = models.CharField(max_length=30)
    age = models.IntegerField(default=0, null = False, blank= False)

    # class Meta:
    #     db_table = 'Reviewer'

    def __str__(self):
        return (self.firstName + ' ' + self.lastName)

# information about the restaurant reviewers

class Restaurant(models.Model) :
    restaurant = models.AutoField(primary_key=True)
    restname = models.CharField(max_length=50)
    restcity = models.CharField(max_length=50)
    reststate = models.CharField(max_length=2)
    typeoffood = models.CharField(max_length=30)
    typeofrest = models.CharField(max_length=30)
    price = models.DecimalField(max_digits=10, decimal_places=2)

    # class Meta:
    #     db_table = 'Restaurant'

    def __str__(self):
        return (self.restname)
    
# information about the restaurant

class Review(models.Model) :
    review = models.AutoField(primary_key=True)
    reviewer = models.ForeignKey(Reviewer,to_field='reviewer', db_column='reviewer',null=True, on_delete=models.SET_NULL)
    restaurant = models.ForeignKey(Restaurant,null=True, to_field = 'restaurant', db_column='restaurant', on_delete=models.SET_NULL)
    # reviewer = models.ForeignKey(Reviewer, to_field='reviewer', db_column='reviewer', NULL=True,on_delete=models.SET_NULL)
    #restaurant = models.ForeignKey(Restaurant, to_field = 'restaurant', db_column='reviewer', NULL=True ,on_delete=models.SET_NULL)
    serviceQuality = models.IntegerField(default=0)
        # be sure to change this in html so that the rating is restricted to  scale of 1-10
    timeliness = models.IntegerField(default=0)
    authenticity  = models.IntegerField(default=0)
    vibe = models.CharField(max_length=30)
    rating = models.IntegerField(default=0)
    comment = models.CharField(max_length=300)

    # class Meta:
    #     db_table = 'Review'

    def __str__(self):
        return(self.rating)
    # information about the review